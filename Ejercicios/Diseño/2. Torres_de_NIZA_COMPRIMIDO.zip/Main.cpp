#include <iostream>
#include "Propietario.h"
#include "Propiedad.h"

using std::cout;
using std::cin;
using std::string; 

void inicializarDatos(){
    Propietario propiet1, propiet2, propiet3, propiet4;

    propiet1.setNombre("Debora Vilar");
    propiet1.setIdentificacion(20202492);
    propiet2.setNombre("Ignacio Rodríguez");
    propiet2.setIdentificacion(30458452);
    propiet3.setNombre("Erika Muñoz");
    propiet3.setIdentificacion(1058845781);
    propiet4.setNombre("Modesto Villaverde");
    propiet4.setIdentificacion(31321432);

    Propiedad prop1, prop2, prop3, prop4;

    prop1.setnumIdentificacion(101);
    prop1.setAreaProp(160);
    prop1.setParqueadero(true);
    prop1.setPiso(10);
    propiet1.setPropiedad(prop1);   //Aun no estamos usando Apuntadores

    prop2.setnumIdentificacion(901);
    prop2.setAreaProp(30);
    prop2.setParqueadero(false);
    prop2.setPiso(9);
    propiet2.setPropiedad(prop2);

    prop3.setnumIdentificacion(701);
    prop3.setAreaProp(45);
    prop3.setParqueadero(true);
    prop3.setPiso(7);
    propiet3.setPropiedad(prop3);

    prop4.setnumIdentificacion(502);
    prop4.setAreaProp(60);
    prop4.setParqueadero(false);
    prop4.setPiso(5);
    propiet4.setPropiedad(prop4);

    cout << "-Propietario 1:\n";
    propiet1.mostrarDatosPropietario();
    cout << "-Propiedad 1:\n";
    prop1.mostrarDatosPropiedad();    //Llamamos a la funcion mostrarDatos para imprimir la informacion de algun prop
    
    cout << "-Propietario 2:\n";
    propiet2.mostrarDatosPropietario();
    cout << "-Propiedad 2:\n";
    prop2.mostrarDatosPropiedad();

    cout << "-Propietario 3:\n";
    propiet3.mostrarDatosPropietario();
    cout << "-Propiedad 3:\n";
    prop3.mostrarDatosPropiedad();

    cout << "-Propietario 4:\n";
    propiet4.mostrarDatosPropietario();
    cout << "-Propiedad 4:\n";
    prop4.mostrarDatosPropiedad();
}

int main()
{
    /*string nombre;
    cout << "Funciono, escribe tu nombre: ";
    cin >> nombre;
    cout << "Tu nombre es: " << nombre;*/
    inicializarDatos();
    return 0;
}