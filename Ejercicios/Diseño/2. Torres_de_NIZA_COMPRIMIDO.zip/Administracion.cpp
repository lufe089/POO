#include <iostream>
#include "Administracion.h"

void Administracion::imprimirUnPropietario(){

}

void Administracion::imprimirPropietarios(){

}

void Administracion::recaudarAdministracion(){

}
