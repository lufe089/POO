#ifndef ADMINISTRACION_H
#define ADMINISTRACION_H 

#include <iostream>

using std::string;

class Administracion{
    private:
        int cobroAscensor;
        int cobroBase;
        float recargo;

    public:
        void imprimirUnPropietario();
        void imprimirPropietarios();
        void recaudarAdministracion();
};

#endif